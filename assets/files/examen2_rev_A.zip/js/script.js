const checkAuthorization = document.getElementById("authorization");
const checkBody = document.getElementById("body"); 

// Le input authorization-value est accessible si le checkbox est coché
checkAuthorization.addEventListener("change", () => {
    const authorizationValue = document.getElementById("authorization-value");
    authorizationValue.disabled = !checkAuthorization.checked;
})

// Le input body-value est accessible si le checkbox est coché
checkBody.addEventListener("change", () => {
    const bodyValue = document.getElementById("body-value");
    bodyValue.disabled = !checkBody.checked;
})

// Ajoutez votre code JavaScript ici

